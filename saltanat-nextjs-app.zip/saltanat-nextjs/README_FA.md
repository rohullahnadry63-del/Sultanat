# اپلیکیشن سلطنت — نسخه Next.js

این پروژه برای اتصال به پروژه فعلی Supabase سلطنت ساخته شده است.

## امکانات این نسخه
- ورود مدیر با کد شش‌رقمی ایمیل و رمز محلی چهاررقمی
- ورود کارمندان با رمز شش‌رقمی از Edge Function موجود `saltanat-staff-access`
- داشبورد، ثبت و فهرست املاک
- شناسنامه ملک و چاپ آن
- بارگذاری تصویر/ویدیو در Storage موجود `saltanat-property-media`
- ثبت و مدیریت مشتریان با شماره خودکار `SL-1405-001`
- ثبت معامله و تقسیم کمیشن ۳۰٪ روح‌الله، ۳۰٪ سدیس، ۳۰٪ خالد و ۱۰٪ وارث
- نقش‌ها: manager، khalid، warith، baesith، sadis

## اتصال
فایل `.env.local` در این بسته با آدرس پروژه و publishable key که قبلاً برای سلطنت داده شده پُر شده است. این کلید publishable است و نباید آن را با service_role یا secret key اشتباه گرفت. هیچ service_role key در این پروژه وجود ندارد.

## نصب و اجرا
```bash
npm install
npm run dev
```
سپس مرورگر را در `http://localhost:3000` باز کنید.

برای ساخت نسخه انتشار:
```bash
npm run build
```

## انتشار در Netlify
این پروژه Next.js سروری است؛ فقط فایل HTML نیست و با drag-and-drop ساده به‌عنوان سایت ایستا منتشر نمی‌شود. باید پروژه به GitHub فرستاده و در Netlify از مسیر Add new site > Import an existing project به GitHub وصل شود. فایل `netlify.toml` تنظیم اولیه را دارد. متغیرهای `.env.local` را در Site configuration > Environment variables نیز وارد کنید؛ فایل `.env.local` به‌دلیل امنیت در Git نادیده گرفته می‌شود.

## نکات مهم پیش از استفاده واقعی
1. در Supabase > Authentication > URL Configuration، آدرس سایت زنده Netlify را به Site URL و Redirect URLs اضافه کنید.
2. در Authentication > Email Templates، ایمیل OTP باید کد شش‌رقمی را نمایش دهد.
3. برای کارمندان، مدیر باید در اپ بخش «دسترسی کارمندان» رمز شش‌رقمی تعیین کند.
4. دسترسی واقعی داده‌ها توسط RLS موجود Supabase کنترل می‌شود؛ پنهان‌کردن منوها به‌تنهایی امنیت نیست.
5. در دیتابیس فعلی یک پروفایل مدیر موجود است؛ حساب‌های کارمندان باید از مسیر Edge Function فعال شوند.
6. این بسته هنوز روی Netlify نشر نشده و ورود/ذخیره‌سازی باید پس از نشر با حساب واقعی آزمایش شود.
