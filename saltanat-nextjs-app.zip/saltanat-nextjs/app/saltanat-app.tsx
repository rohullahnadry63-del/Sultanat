'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import { createClient } from '@/lib/supabase/client'

type Role = 'manager' | 'khalid' | 'warith' | 'baesith' | 'sadis'
type Property = { id: string; code: string | null; owner_name: string; owner_phone: string | null; property_type: string; deal_type: string; price: number; area: number | null; location: string | null; document_status: string; notes: string | null; created_at: string }
type Customer = { id: string; customer_code: string; full_name: string; phone: string; request_type: string; property_type: string; budget: number; location: string; rooms: string | null; status: string; next_follow_up: string | null; notes: string | null; created_at: string }
type Tx = { id: string; property_id: string; transaction_type: string; amount: number; office_commission: number; transaction_date: string; notes: string | null }
type Visit = { id: string; customer_id: string; property_id: string; visit_date: string; result: string; feedback: string | null }
type Media = { id: string; property_id: string; storage_path: string; media_type: string; caption: string | null }

const db = () => createClient()
const managerEmail = process.env.NEXT_PUBLIC_MANAGER_EMAIL || 'rohullahnadry63@gmail.com'
const roleNames: Record<Role, string> = { manager: 'مدیر دفتر', khalid: 'خالد — مسئول ساحه', warith: 'وارث — عکس و ویدیو', baesith: 'باعث — اسناد و حساب', sadis: 'سدیس — نمایش املاک' }
const roleOrder: Role[] = ['khalid', 'warith', 'baesith', 'sadis']
const statusNames: Record<string, string> = { new: 'جدید', follow_up: 'در پیگیری', serious: 'مشتری جدی', closed: 'معامله شد', cancelled: 'منصرف شد' }
const faNumber = (n: number | string | null | undefined) => n == null ? '—' : Number(n).toLocaleString('fa-AF')
const hashPin = async (pin: string) => {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(pin))
  return Array.from(new Uint8Array(digest)).map(x => x.toString(16).padStart(2, '0')).join('')
}

export default function SaltanatApp() {
  const [user, setUser] = useState<any>(null)
  const [role, setRole] = useState<Role | null>(null)
  const [fullName, setFullName] = useState('')
  const [loading, setLoading] = useState(true)
  const [notice, setNotice] = useState('')
  const [section, setSection] = useState('home')
  const [authStage, setAuthStage] = useState<'email' | 'otp' | 'manager-pin' | 'unlock' | 'staff'>('email')
  const [authBusy, setAuthBusy] = useState(false)
  const [otp, setOtp] = useState('')
  const [pin, setPin] = useState('')
  const [pin2, setPin2] = useState('')
  const [staffRole, setStaffRole] = useState<Role>('khalid')
  const [staffPin, setStaffPin] = useState('')
  const [properties, setProperties] = useState<Property[]>([])
  const [customers, setCustomers] = useState<Customer[]>([])
  const [transactions, setTransactions] = useState<Tx[]>([])
  const [visits, setVisits] = useState<Visit[]>([])
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null)
  const [media, setMedia] = useState<Record<string, string>>({})
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null)
  const [propertyFormOpen, setPropertyFormOpen] = useState(false)
  const [customerFormOpen, setCustomerFormOpen] = useState(false)
  const [transactionFormOpen, setTransactionFormOpen] = useState(false)
  const [staffCode, setStaffCode] = useState('')
  const [staffCodeRole, setStaffCodeRole] = useState<Role>('khalid')

  const canSeeCustomers = role === 'manager' || role === 'sadis'
  const canAddProperty = role === 'manager' || role === 'khalid'
  const canUploadMedia = role === 'manager' || role === 'warith'
  const canFinance = role === 'manager' || role === 'baesith'

  const loadData = useCallback(async (currentRole: Role) => {
    const supabase = db()
    const p = await supabase.from('properties').select('*').order('created_at', { ascending: false })
    if (!p.error) {
      const rows = (p.data || []) as Property[]
      setProperties(rows)
      const mediaRows = await supabase.from('property_media').select('*').order('created_at', { ascending: false })
      if (!mediaRows.error) {
        const urls: Record<string, string> = {}
        for (const item of (mediaRows.data || []) as Media[]) {
          if (item.media_type === 'image' && !urls[item.property_id]) {
            const signed = await supabase.storage.from('saltanat-property-media').createSignedUrl(item.storage_path, 3600)
            if (signed.data?.signedUrl) urls[item.property_id] = signed.data.signedUrl
          }
        }
        setMedia(urls)
      }
    } else setNotice(`بارگذاری املاک: ${p.error.message}`)
    if (currentRole === 'manager' || currentRole === 'sadis') {
      const c = await supabase.from('customers').select('*').order('created_at', { ascending: false })
      if (!c.error) setCustomers((c.data || []) as Customer[])
      else setNotice(`بارگذاری مشتریان: ${c.error.message}`)
      const v = await supabase.from('customer_property_visits').select('*').order('visit_date', { ascending: false })
      if (!v.error) setVisits((v.data || []) as Visit[])
    }
    if (currentRole === 'manager' || currentRole === 'baesith') {
      const t = await supabase.from('transactions').select('*').order('transaction_date', { ascending: false })
      if (!t.error) setTransactions((t.data || []) as Tx[])
      else setNotice(`بارگذاری معاملات: ${t.error.message}`)
    }
  }, [])

  const acceptSignedInUser = useCallback(async (userId: string, expectedRole?: Role) => {
    const supabase = db()
    const { data, error } = await supabase.from('profiles').select('full_name, role').eq('id', userId).single()
    if (error || !data) throw new Error('حساب کاربری در سیستم سلطنت ثبت نیست. مدیر باید دسترسی شما را فعال کند.')
    const actualRole = data.role as Role
    if (!['manager', 'khalid', 'warith', 'baesith', 'sadis'].includes(actualRole)) throw new Error('نقش حساب کاربری معتبر نیست.')
    if (expectedRole && actualRole !== expectedRole) throw new Error('نقش حساب با انتخاب شما مطابقت ندارد.')
    setUser({ id: userId })
    setRole(actualRole)
    setFullName(data.full_name || roleNames[actualRole])
    if (actualRole === 'manager') localStorage.setItem('saltanat_role', 'manager')
    else localStorage.setItem('saltanat_role', actualRole)
    await loadData(actualRole)
  }, [loadData])

  useEffect(() => {
    let alive = true
    const start = async () => {
      try {
        const supabase = db()
        const { data: { session } } = await supabase.auth.getSession()
        if (!alive) return
        if (session?.user) {
          const savedRole = localStorage.getItem('saltanat_role') as Role | null
          const pinHash = localStorage.getItem('saltanat_manager_pin_hash')
          if (savedRole === 'manager' && pinHash) {
            setUser({ id: session.user.id }); setRole('manager'); setAuthStage('unlock')
          } else {
            await acceptSignedInUser(session.user.id, savedRole || undefined)
            if (!pinHash) setAuthStage('manager-pin')
          }
        } else setAuthStage('email')
      } catch (e: any) { setNotice(e.message || 'ورود آماده نشد.') }
      finally { if (alive) setLoading(false) }
    }
    start()
    const { data: listener } = db().auth.onAuthStateChange((_event, session) => {
      if (!session) { setUser(null); setRole(null); setFullName('') }
    })
    return () => { alive = false; listener.subscription.unsubscribe() }
  }, [acceptSignedInUser])

  async function sendOtp() {
    setAuthBusy(true); setNotice('در حال فرستادن کد تأیید به ایمیل مدیر…')
    try {
      const { error } = await db().auth.signInWithOtp({ email: managerEmail, options: { shouldCreateUser: true } })
      if (error) throw error
      setAuthStage('otp'); setNotice('کد شش‌رقمی به ایمیل مدیر فرستاده شد. صندوق ورودی و Spam را بررسی کنید.')
    } catch (e: any) { setNotice(`ارسال کد انجام نشد: ${e.message}`) }
    finally { setAuthBusy(false) }
  }

  async function verifyManagerOtp() {
    if (!/^\d{6}$/.test(otp)) { setNotice('کد باید شش رقم باشد.'); return }
    setAuthBusy(true); setNotice('در حال تأیید ایمیل…')
    try {
      const { data, error } = await db().auth.verifyOtp({ email: managerEmail, token: otp, type: 'email' })
      if (error || !data.user) throw error || new Error('کد تأیید نشد.')
      const { error: bootError } = await db().functions.invoke('saltanat-bootstrap-manager', { body: {} })
      if (bootError) throw new Error(`تأیید ایمیل انجام شد، اما فعال‌سازی مدیر تکمیل نشد: ${bootError.message}`)
      setUser({ id: data.user.id }); setAuthStage('manager-pin'); setNotice('ایمیل تأیید شد. برای مدیر یک رمز چهاررقمی تعیین کنید.')
    } catch (e: any) { setNotice(`تأیید انجام نشد: ${e.message}`) }
    finally { setAuthBusy(false) }
  }

  async function saveManagerPin() {
    if (!/^\d{4}$/.test(pin)) { setNotice('رمز مدیر باید دقیقاً چهار رقم باشد.'); return }
    if (pin !== pin2) { setNotice('دو رمز یکسان نیست.'); return }
    try {
      localStorage.setItem('saltanat_manager_pin_hash', await hashPin(pin))
      localStorage.setItem('saltanat_role', 'manager')
      const { data: { user: current } } = await db().auth.getUser()
      if (!current) throw new Error('نشست ورود پیدا نشد؛ دوباره ایمیل را تأیید کنید.')
      await acceptSignedInUser(current.id, 'manager')
      setAuthStage('email'); setNotice('ورود مدیر آماده شد.')
    } catch (e: any) { setNotice(e.message) }
  }

  async function unlockManager() {
    if (!/^\d{4}$/.test(pin)) { setNotice('رمز چهاررقمی را وارد کنید.'); return }
    const stored = localStorage.getItem('saltanat_manager_pin_hash')
    if (!stored || await hashPin(pin) !== stored) { setNotice('رمز نادرست است.'); return }
    const { data: { user: current } } = await db().auth.getUser()
    if (!current) { setAuthStage('email'); setNotice('نشست پایان یافته؛ دوباره با ایمیل وارد شوید.'); return }
    try { await acceptSignedInUser(current.id, 'manager'); setNotice('خوش آمدید.') }
    catch (e: any) { setNotice(e.message) }
  }

  async function loginStaff() {
    if (!/^\d{6}$/.test(staffPin)) { setNotice('رمز کارمند باید شش رقم باشد.'); return }
    setAuthBusy(true); setNotice('در حال بررسی رمز کارمند…')
    try {
      const { data, error } = await db().functions.invoke('saltanat-staff-access', { body: { action: 'login', role: staffRole, pin: staffPin } })
      if (error || !data?.token_hash) throw new Error(data?.error || error?.message || 'ورود کارمند انجام نشد.')
      const { data: authData, error: authError } = await db().auth.verifyOtp({ token_hash: data.token_hash, type: 'email' })
      if (authError || !authData.user) throw authError || new Error('نشست کارمند ساخته نشد.')
      await acceptSignedInUser(authData.user.id, staffRole)
      setNotice(`ورود ${roleNames[staffRole]} موفق بود.`)
    } catch (e: any) { setNotice(e.message) }
    finally { setAuthBusy(false) }
  }

  async function logout() {
    await db().auth.signOut()
    localStorage.removeItem('saltanat_role')
    setUser(null); setRole(null); setFullName(''); setSection('home'); setAuthStage('email'); setNotice('از حساب خارج شدید.')
  }

  async function createProperty(form: FormData) {
    if (!role || !canAddProperty) return
    const row = {
      code: `SL-P-${Date.now().toString(36).toUpperCase()}`,
      owner_name: String(form.get('owner_name') || '').trim(),
      owner_phone: String(form.get('owner_phone') || '').trim() || null,
      property_type: String(form.get('property_type') || ''),
      deal_type: String(form.get('deal_type') || 'sale'),
      price: Number(form.get('price')),
      area: Number(form.get('area')) || null,
      location: String(form.get('location') || '').trim(),
      document_status: String(form.get('document_status') || 'pending'),
      notes: String(form.get('notes') || '').trim() || null,
    }
    if (!row.owner_name || !row.location || !Number.isFinite(row.price) || row.price < 0) { setNotice('نام مالک، موقعیت و قیمت را درست وارد کنید.'); return }
    const { data, error } = await db().from('properties').insert(row).select('*').single()
    if (error) { setNotice(`ثبت ملک ناموفق بود: ${error.message}`); return }
    const property = data as Property
    const file = form.get('photo') as File | null
    if (file && file.size > 0 && canUploadMedia) {
      const path = `${property.id}/${Date.now()}-${file.name.replace(/[^\p{L}\p{N}._-]/gu, '-')}`
      const upload = await db().storage.from('saltanat-property-media').upload(path, file, { upsert: false })
      if (!upload.error) await db().from('property_media').insert({ property_id: property.id, storage_path: path, media_type: 'image', caption: 'تصویر اصلی ملک' })
      else setNotice(`ملک ثبت شد؛ اما عکس بارگذاری نشد: ${upload.error.message}`)
    }
    setPropertyFormOpen(false); await loadData(role); setSelectedProperty(property); setNotice(`ملک با موفقیت ثبت شد. شماره: ${property.code || 'در حال تعیین'}`)
  }

  async function uploadPropertyMedia(form: FormData) {
    if (!selectedProperty || !canUploadMedia) return
    const file = form.get('media') as File | null
    if (!file || !file.size) { setNotice('لطفاً عکس یا ویدیو انتخاب کنید.'); return }
    const type = file.type.startsWith('video/') ? 'video' : file.type.startsWith('image/') ? 'image' : 'document'
    const path = `${selectedProperty.id}/${Date.now()}-${file.name.replace(/[^\p{L}\p{N}._-]/gu, '-')}`
    const { error } = await db().storage.from('saltanat-property-media').upload(path, file)
    if (error) { setNotice(`بارگذاری فایل انجام نشد: ${error.message}`); return }
    const saved = await db().from('property_media').insert({ property_id: selectedProperty.id, storage_path: path, media_type: type, caption: String(form.get('caption') || '') })
    if (saved.error) { setNotice(`فایل بارگذاری شد، اما مشخصات آن ثبت نشد: ${saved.error.message}`); return }
    await loadData(role!); setNotice('فایل ملک ذخیره شد.')
  }

  async function createCustomer(form: FormData) {
    if (!canSeeCustomers) return
    const row = {
      full_name: String(form.get('full_name') || '').trim(), phone: String(form.get('phone') || '').trim(),
      request_type: String(form.get('request_type') || 'purchase'), property_type: String(form.get('property_type') || 'خانه'),
      budget: Number(form.get('budget')), location: String(form.get('location') || '').trim(), rooms: String(form.get('rooms') || '') || null,
      document_requirement: String(form.get('document_requirement') || 'قباله شرعی'), notes: String(form.get('notes') || '') || null,
      next_follow_up: String(form.get('next_follow_up') || '') || null, assigned_to: 'سدیس',
    }
    if (!row.full_name || !row.phone || !row.location || !Number.isFinite(row.budget) || row.budget < 0) { setNotice('نام، شماره، موقعیت و بودجه را درست وارد کنید.'); return }
    const { error } = await db().from('customers').insert(row)
    if (error) { setNotice(`ثبت مشتری ناموفق بود: ${error.message}`); return }
    setCustomerFormOpen(false); await loadData(role!); setNotice('مشتری ثبت شد و شماره شناسایی خودکار گرفت.')
  }

  async function saveCustomerVisit(form: FormData) {
    if (!selectedCustomer || !canSeeCustomers) return
    const propertyId = String(form.get('property_id') || '')
    if (!propertyId) { setNotice('لطفاً ملک مورد نظر را انتخاب کنید.'); return }
    const { error } = await db().from('customer_property_visits').insert({ customer_id: selectedCustomer.id, property_id: propertyId, result: String(form.get('result') || 'interested'), feedback: String(form.get('feedback') || '') })
    if (error) { setNotice(`ثبت بازدید ناموفق بود: ${error.message}`); return }
    setSelectedCustomer(null); await loadData(role!); setNotice('بازدید ملک برای مشتری ثبت شد.')
  }

  async function changeCustomerStatus(id: string, status: string) {
    const { error } = await db().from('customers').update({ status }).eq('id', id)
    if (error) setNotice(`تغییر وضعیت ناموفق بود: ${error.message}`)
    else { await loadData(role!); setNotice('وضعیت مشتری به‌روز شد.') }
  }

  async function createTransaction(form: FormData) {
    if (!canFinance) return
    const propertyId = String(form.get('property_id') || '')
    const amount = Number(form.get('amount'))
    const commission = Number(form.get('office_commission'))
    if (!propertyId || !Number.isFinite(amount) || amount <= 0 || !Number.isFinite(commission) || commission < 0) { setNotice('ملک، مبلغ معامله و کمیشن را درست وارد کنید.'); return }
    const { data, error } = await db().from('transactions').insert({ property_id: propertyId, transaction_type: String(form.get('transaction_type') || 'sale'), amount, office_commission: commission, transaction_date: String(form.get('transaction_date') || new Date().toISOString().slice(0, 10)), notes: String(form.get('notes') || '') }).select('*').single()
    if (error) { setNotice(`ثبت معامله ناموفق بود: ${error.message}`); return }
    const shares = [
      { recipient_name: 'روح‌الله', percentage: 30 }, { recipient_name: 'سدیس', percentage: 30 },
      { recipient_name: 'خالد', percentage: 30 }, { recipient_name: 'وارث', percentage: 10 },
    ].map(s => ({ transaction_id: data.id, ...s, amount: Math.round(commission * s.percentage) / 100 }))
    const shareResult = await db().from('commission_shares').insert(shares)
    setTransactionFormOpen(false); await loadData(role!)
    setNotice(shareResult.error ? `معامله ثبت شد؛ تقسیم کمیشن نیاز به بررسی دارد: ${shareResult.error.message}` : 'معامله و تقسیم کمیشن ۳۰٪، ۳۰٪، ۳۰٪ و ۱۰٪ ثبت شد.')
  }

  async function setEmployeePin() {
    if (!/^\d{6}$/.test(staffCode)) { setNotice('رمز کارمند باید شش رقم باشد.'); return }
    const { error } = await db().functions.invoke('saltanat-staff-access', { body: { action: 'set_code', role: staffCodeRole, pin: staffCode } })
    if (error) setNotice(`ثبت رمز کارمند انجام نشد: ${error.message}`)
    else { setStaffCode(''); setNotice(`رمز ${roleNames[staffCodeRole]} ثبت شد.`) }
  }

  const totals = useMemo(() => ({ properties: properties.length, customers: customers.length, deals: transactions.length, commission: transactions.reduce((s, t) => s + Number(t.office_commission || 0), 0) }), [properties, customers, transactions])
  const nav = [
    ['home', 'داشبورد', '⌂', true], ['properties', 'املاک', '▦', true], ['customers', 'مشتریان', '♙', canSeeCustomers],
    ['transactions', 'معاملات و کمیشن', '◈', canFinance], ['staff', 'دسترسی کارمندان', '⚙', role === 'manager'],
  ].filter(x => x[3]) as [string, string, string, boolean][]

  if (loading) return <main className="center-screen"><div className="loader"/><p>در حال آماده‌سازی سلطنت…</p></main>
  if (!user || !role || (role === 'manager' && (authStage === 'manager-pin' || authStage === 'unlock'))) {
    const signed = Boolean(user && role)
    return <main className="auth-page"><section className="auth-card">
      <div className="crown">♛</div><div className="brand">سلطنت</div><p className="muted">رهنما و معاملات املاک</p>
      {!signed && authStage === 'email' && <><h1>ورود مدیر دفتر</h1><p>کد شش‌رقمی به ایمیل مدیر ارسال می‌شود.</p><button className="primary full" disabled={authBusy} onClick={sendOtp}>{authBusy ? 'لطفاً صبر کنید…' : `ارسال کد به ${managerEmail}`}</button><button className="link-button" onClick={() => { setAuthStage('staff'); setNotice('رمز شش‌رقمی کارمند را وارد کنید.') }}>ورود کارمندان</button></>}
      {!signed && authStage === 'otp' && <><h1>تأیید ایمیل</h1><p>کد شش‌رقمی ارسال‌شده به ایمیل را وارد کنید.</p><input className="field ltr" inputMode="numeric" maxLength={6} placeholder="000000" value={otp} onChange={e => setOtp(e.target.value.replace(/\D/g, ''))}/><button className="primary full" disabled={authBusy} onClick={verifyManagerOtp}>تأیید کد</button><button className="link-button" onClick={() => setAuthStage('email')}>بازگشت</button></>}
      {(authStage === 'manager-pin') && <><h1>رمز مدیر</h1><p>یک رمز چهاررقمی برای بازکردن اپ در این دستگاه بسازید.</p><input className="field ltr" inputMode="numeric" maxLength={4} placeholder="رمز چهاررقمی" value={pin} onChange={e => setPin(e.target.value.replace(/\D/g, ''))}/><input className="field ltr" inputMode="numeric" maxLength={4} placeholder="تکرار رمز" value={pin2} onChange={e => setPin2(e.target.value.replace(/\D/g, ''))}/><button className="primary full" onClick={saveManagerPin}>ثبت رمز و ورود</button></>}
      {signed && authStage === 'unlock' && <><h1>بازکردن سلطنت</h1><p>رمز چهاررقمی مدیر را وارد کنید.</p><input className="field ltr" inputMode="numeric" maxLength={4} placeholder="رمز مدیر" value={pin} onChange={e => setPin(e.target.value.replace(/\D/g, ''))}/><button className="primary full" onClick={unlockManager}>ورود</button><button className="link-button" onClick={logout}>خروج از حساب</button></>}
      {!signed && authStage === 'staff' && <><h1>ورود کارمند</h1><p>نقش خود را انتخاب و رمز شش‌رقمی را وارد کنید.</p><select className="field" value={staffRole} onChange={e => setStaffRole(e.target.value as Role)}>{roleOrder.map(r => <option key={r} value={r}>{roleNames[r]}</option>)}</select><input className="field ltr" inputMode="numeric" maxLength={6} placeholder="رمز شش‌رقمی" value={staffPin} onChange={e => setStaffPin(e.target.value.replace(/\D/g, ''))}/><button className="primary full" disabled={authBusy} onClick={loginStaff}>ورود کارمند</button><button className="link-button" onClick={() => setAuthStage('email')}>بازگشت به ورود مدیر</button></>}
      {notice && <div className="notice">{notice}</div>}
      <div className="auth-foot">سلطنت؛ نام مطمین و اعتماد ماندگار</div>
    </section></main>
  }

  return <main className="app-shell">
    <aside className="sidebar"><div className="side-brand"><span>♛</span><div><b>سلطنت</b><small>سامانه مدیریت املاک</small></div></div><div className="user-chip"><div className="avatar">{(fullName || 'س').slice(0, 1)}</div><div><b>{fullName}</b><small>{roleNames[role]}</small></div></div><nav>{nav.map(([key, label, icon]) => <button key={key} className={section === key ? 'nav-item active' : 'nav-item'} onClick={() => { setSection(key); setSelectedProperty(null) }}><span>{icon}</span>{label}</button>)}</nav><button className="logout" onClick={logout}>خروج از حساب</button></aside>
    <section className="main-area"><header className="topbar"><div><small>رهنما و معاملات</small><h1>{nav.find(n => n[0] === section)?.[1] || 'سلطنت'}</h1></div><div className="top-user"><span className="live-dot"/> آنلاین <b>{fullName}</b></div></header>
      {notice && <div className="notice global-notice"><span>{notice}</span><button onClick={() => setNotice('')}>×</button></div>}
      {section === 'home' && <><div className="welcome"><div><span className="eyebrow">مدیریت هوشمند املاک</span><h2>به سلطنت خوش آمدید</h2><p>هر ملک، یک شناسنامه؛ هر معامله، یک حساب روشن.</p></div><div className="welcome-mark">♛</div></div><div className="stats-grid"><Stat label="مجموع املاک" value={faNumber(totals.properties)} hint="املاک ثبت‌شده"/><Stat label="مشتریان" value={faNumber(totals.customers)} hint="درخواست‌های ثبت‌شده"/><Stat label="معاملات" value={faNumber(totals.deals)} hint="معاملات ثبت‌شده"/><Stat label="کمیشن دفتر" value={`${faNumber(totals.commission)} افغانی`} hint="مجموع کمیشن ثبت‌شده"/></div><div className="panel"><div className="panel-head"><h3>آخرین املاک</h3><button className="text-action" onClick={() => setSection('properties')}>دیدن همه</button></div><PropertyList rows={properties.slice(0, 5)} media={media} onSelect={setSelectedProperty}/></div></>}
      {section === 'properties' && <><div className="section-head"><div><h2>مدیریت املاک</h2><p>ثبت، جستجو و شناسنامهٔ املاک سلطنت</p></div>{canAddProperty && <button className="primary" onClick={() => setPropertyFormOpen(v => !v)}>＋ ثبت ملک جدید</button>}</div>{propertyFormOpen && <div className="panel"><h3>ثبت مشخصات ملک</h3><form action={createProperty} className="form-grid"><Field label="نام مالک" name="owner_name" required/><Field label="شماره تماس مالک" name="owner_phone"/><SelectField label="نوع ملک" name="property_type" options={['خانه','زمین','بلاک رهایشی','دوکان','دفتر','آپارتمان','باغ']}/><SelectField label="نوع معامله" name="deal_type" options={['sale','rent','mortgage']} labels={['فروشی','کرایی','گروی']}/><Field label="قیمت (افغانی)" name="price" type="number" required/><Field label="مساحت (متر مربع)" name="area" type="number"/><Field label="موقعیت ملک" name="location" required/><SelectField label="وضعیت اسناد" name="document_status" options={['pending','checked','incomplete']} labels={['در انتظار بررسی','بررسی شده','ناقص']}/><label className="form-field"><span>عکس اصلی ملک {canUploadMedia ? '' : '(فقط وارث یا مدیر)'}</span><input name="photo" type="file" accept="image/*" disabled={!canUploadMedia}/></label><label className="form-field wide"><span>یادداشت</span><textarea name="notes" rows={2}/></label><div className="form-actions"><button className="primary" type="submit">ذخیره ملک</button><button type="button" className="secondary" onClick={() => setPropertyFormOpen(false)}>لغو</button></div></form></div>}<div className="panel"><PropertyList rows={properties} media={media} onSelect={setSelectedProperty}/></div>{selectedProperty && <PropertyDetails property={selectedProperty} image={media[selectedProperty.id]} canUpload={canUploadMedia} onClose={() => setSelectedProperty(null)} onUpload={uploadPropertyMedia}/>}</>}
      {section === 'customers' && <><div className="section-head"><div><h2>مدیریت مشتریان</h2><p>شماره‌گذاری خودکار و پیگیری درخواست‌ها</p></div><button className="primary" onClick={() => setCustomerFormOpen(v => !v)}>＋ ثبت مشتری</button></div>{customerFormOpen && <div className="panel"><h3>فرم ثبت مشتری</h3><form action={createCustomer} className="form-grid"><Field label="نام مشتری" name="full_name" required/><Field label="شماره تماس" name="phone" required/><SelectField label="درخواست مشتری" name="request_type" options={['purchase','rent','sale']} labels={['خرید','کرایه','فروش ملک']}/><SelectField label="نوع ملک" name="property_type" options={['خانه','زمین','بلاک','دوکان','آپارتمان']}/><Field label="بودجه (افغانی)" name="budget" type="number" required/><Field label="موقعیت دلخواه" name="location" required/><Field label="تعداد اتاق" name="rooms"/><SelectField label="اسناد مورد نیاز" name="document_requirement" options={['قباله شرعی','قباله عرفی','هر نوع سند','مهم نیست']}/><Field label="تاریخ پیگیری" name="next_follow_up" type="date"/><label className="form-field wide"><span>یادداشت</span><textarea name="notes" rows={2}/></label><div className="form-actions"><button className="primary" type="submit">ذخیره مشتری</button><button className="secondary" type="button" onClick={() => setCustomerFormOpen(false)}>لغو</button></div></form></div>}<div className="panel"><div className="table-wrap"><table><thead><tr><th>شماره</th><th>نام و تماس</th><th>درخواست</th><th>بودجه</th><th>موقعیت</th><th>وضعیت</th><th>بازدید</th></tr></thead><tbody>{customers.map(c => <tr key={c.id}><td><b>{c.customer_code}</b></td><td>{c.full_name}<small className="subline">{c.phone}</small></td><td>{c.request_type === 'purchase' ? 'خرید' : c.request_type === 'rent' ? 'کرایه' : 'فروش'}</td><td>{faNumber(c.budget)}</td><td>{c.location}</td><td><select className="status-select" value={c.status} onChange={e => changeCustomerStatus(c.id, e.target.value)}>{Object.entries(statusNames).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></td><td><button className="small-action" onClick={() => setSelectedCustomer(c)}>ثبت بازدید</button><small className="subline">{faNumber(visits.filter(v => v.customer_id === c.id).length)} بازدید</small></td></tr>)}</tbody></table>{!customers.length && <Empty text="هنوز مشتری ثبت نشده است."/>}</div></div>{selectedCustomer && <div className="modal-backdrop"><div className="property-card"><div className="property-card-head"><div><span className="eyebrow">ثبت بازدید مشتری</span><h2>{selectedCustomer.full_name}</h2></div><button className="close" onClick={() => setSelectedCustomer(null)}>×</button></div><form action={saveCustomerVisit} className="form-grid"><SelectField label="ملک نمایش‌داده‌شده" name="property_id" options={properties.map(p => p.id)} labels={properties.map(p => `${p.code || ''} — ${p.property_type} — ${p.location || ''}`)}/><SelectField label="نتیجه بازدید" name="result" options={['interested','thinking','rejected','offer_made']} labels={['علاقه‌مند شد','در فکر است','نپذیرفت','پیشنهاد قیمت داد']}/><label className="form-field wide"><span>یادداشت بازدید</span><textarea name="feedback" rows={3}/></label><div className="form-actions"><button className="primary">ذخیره بازدید</button><button type="button" className="secondary" onClick={() => setSelectedCustomer(null)}>لغو</button></div></form></div></div>}</>}
      {section === 'transactions' && <><div className="section-head"><div><h2>معاملات و کمیشن</h2><p>ثبت مبلغ معامله و تقسیم کمیشن دفتر</p></div><button className="primary" onClick={() => setTransactionFormOpen(v => !v)}>＋ ثبت معامله</button></div>{transactionFormOpen && <div className="panel"><h3>ثبت معامله جدید</h3><form action={createTransaction} className="form-grid"><SelectField label="ملک" name="property_id" options={properties.map(p => p.id)} labels={properties.map(p => `${p.code || ''} — ${p.owner_name} — ${p.location || ''}`)}/><SelectField label="نوع معامله" name="transaction_type" options={['sale','rent','mortgage']} labels={['فروش','کرایه','گروی']}/><Field label="مبلغ معامله (افغانی)" name="amount" type="number" required/><Field label="کمیشن دفتر (افغانی)" name="office_commission" type="number" required/><Field label="تاریخ معامله" name="transaction_date" type="date"/><label className="form-field wide"><span>یادداشت</span><textarea name="notes" rows={2}/></label><div className="split-preview wide"><b>تقسیم خودکار کمیشن:</b> روح‌الله ۳۰٪ · سدیس ۳۰٪ · خالد ۳۰٪ · وارث ۱۰٪</div><div className="form-actions"><button className="primary" type="submit">ثبت معامله و تقسیم کمیشن</button><button type="button" className="secondary" onClick={() => setTransactionFormOpen(false)}>لغو</button></div></form></div>}<div className="panel"><div className="table-wrap"><table><thead><tr><th>تاریخ</th><th>شماره ملک</th><th>نوع</th><th>مبلغ معامله</th><th>کمیشن دفتر</th></tr></thead><tbody>{transactions.map(t => <tr key={t.id}><td>{t.transaction_date}</td><td>{properties.find(p => p.id === t.property_id)?.code || '—'}</td><td>{t.transaction_type === 'sale' ? 'فروش' : t.transaction_type === 'rent' ? 'کرایه' : 'گروی'}</td><td>{faNumber(t.amount)}</td><td>{faNumber(t.office_commission)}</td></tr>)}</tbody></table>{!transactions.length && <Empty text="هنوز معامله ثبت نشده است."/>}</div></div></>}
      {section === 'staff' && <div className="panel staff-panel"><h2>مدیریت دسترسی کارمندان</h2><p>برای هر کارمند رمز شش‌رقمی تعیین کنید. هر کارمند فقط بخش مربوط به وظیفه‌اش را می‌بیند.</p><div className="staff-list">{roleOrder.map(r => <div className="staff-row" key={r}><div className="staff-icon">♙</div><div><b>{roleNames[r]}</b><small>{r === 'khalid' ? 'ثبت املاک و معلومات ساحه' : r === 'warith' ? 'عکس، ویدیو و فایل‌های ملک' : r === 'baesith' ? 'اسناد، معاملات و حساب کمیشن' : 'فقط مشاهده املاک و مدیریت مشتریان'}</small></div></div>)}</div><div className="form-grid staff-code-form"><SelectField label="انتخاب کارمند" name="staff-role" value={staffCodeRole} onChange={v => setStaffCodeRole(v as Role)} options={roleOrder} labels={roleOrder.map(r => roleNames[r])}/><label className="form-field"><span>رمز شش‌رقمی</span><input className="ltr" inputMode="numeric" maxLength={6} value={staffCode} onChange={e => setStaffCode(e.target.value.replace(/\D/g, ''))}/></label><div className="form-actions"><button className="primary" onClick={setEmployeePin}>ثبت / تغییر رمز</button></div></div></div>}
    </section>
  </main>
}

function Stat({ label, value, hint }: { label: string; value: string; hint: string }) { return <div className="stat-card"><span>{label}</span><strong>{value}</strong><small>{hint}</small></div> }
function Field({ label, name, type = 'text', required = false }: { label: string; name: string; type?: string; required?: boolean }) { return <label className="form-field"><span>{label}</span><input name={name} type={type} required={required} min={type === 'number' ? 0 : undefined}/></label> }
function SelectField({ label, name, options, labels, value, onChange }: { label: string; name: string; options: string[]; labels?: string[]; value?: string; onChange?: (v: string) => void }) { return <label className="form-field"><span>{label}</span><select name={name} value={value} onChange={e => onChange?.(e.target.value)}>{options.map((o, i) => <option key={o} value={o}>{labels?.[i] || o}</option>)}</select></label> }
function Empty({ text }: { text: string }) { return <div className="empty">{text}</div> }
function PropertyList({ rows, media, onSelect }: { rows: Property[]; media: Record<string, string>; onSelect: (p: Property) => void }) { return <div className="property-list">{rows.map(p => <button className="property-row" key={p.id} onClick={() => onSelect(p)}><div className="property-thumb">{media[p.id] ? <img src={media[p.id]} alt="تصویر ملک"/> : <span>♜</span>}</div><div className="property-main"><b>{p.property_type} — {p.owner_name}</b><small>{p.location || 'موقعیت ثبت نشده'} · {p.area ? `${faNumber(p.area)} متر` : 'مساحت نامشخص'}</small><small className="code-label">{p.code || 'شماره در حال تعیین'}</small></div><div className="property-price"><b>{faNumber(p.price)}</b><small>افغانی</small></div></button>)}{!rows.length && <Empty text="هنوز ملکی ثبت نشده است."/>}</div> }
function PropertyDetails({ property, image, canUpload, onClose, onUpload }: { property: Property; image?: string; canUpload: boolean; onClose: () => void; onUpload: (form: FormData) => void }) { return <div className="modal-backdrop"><div className="property-card"><div className="property-card-head"><div><span className="eyebrow">شناسنامه ملک سلطنت</span><h2>{property.code || 'ملک سلطنت'}</h2></div><button className="close" onClick={onClose}>×</button></div>{image && <img className="card-photo" src={image} alt="تصویر ملک"/>}<div className="identity-grid"><div><small>مالک</small><b>{property.owner_name}</b></div><div><small>نوع ملک</small><b>{property.property_type}</b></div><div><small>قیمت</small><b>{faNumber(property.price)} افغانی</b></div><div><small>مساحت</small><b>{property.area ? `${faNumber(property.area)} متر مربع` : '—'}</b></div><div><small>موقعیت</small><b>{property.location || '—'}</b></div><div><small>اسناد</small><b>{property.document_status === 'checked' ? 'بررسی شده' : property.document_status === 'incomplete' ? 'ناقص' : 'در انتظار بررسی'}</b></div><div><small>تماس مالک</small><b>{property.owner_phone || '—'}</b></div><div><small>نوع معامله</small><b>{property.deal_type === 'sale' ? 'فروشی' : property.deal_type === 'rent' ? 'کرایی' : 'گروی'}</b></div></div>{property.notes && <p className="notes">{property.notes}</p>}{canUpload && <form action={onUpload} className="upload-inline"><b>افزودن عکس یا ویدیو</b><input name="media" type="file" accept="image/*,video/*" required/><input name="caption" placeholder="توضیح فایل (اختیاری)"/><button className="primary">بارگذاری فایل</button></form>}<div className="card-actions"><button className="secondary" onClick={() => window.print()}>چاپ شناسنامه</button><button className="primary" onClick={onClose}>بستن</button></div></div></div> }
