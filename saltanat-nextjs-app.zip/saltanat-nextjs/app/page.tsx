import SaltanatApp from './saltanat-app'
export default function Home() { return <SaltanatApp /> }
