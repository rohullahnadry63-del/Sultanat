import type { Metadata, Viewport } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'سلطنت | رهنما و معاملات املاک',
  description: 'سامانه آنلاین مدیریت املاک، مشتریان و معاملات سلطنت',
  applicationName: 'سلطنت',
  appleWebApp: { capable: true, statusBarStyle: 'default', title: 'سلطنت' },
}
export const viewport: Viewport = { width: 'device-width', initialScale: 1, maximumScale: 1, themeColor: '#111111' }

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="fa" dir="rtl"><body>{children}</body></html>
}
